<?php
include_once "sessao.php";
include_once "conexao.php";

$idCombo = $_REQUEST['idCombo'] ?? '';
$alocacaoAtual = null;

$sqlAlocacoes = "SELECT oe.idEngenheiro, oe.idObra, e.dsNome, o.Descricao 
                 FROM obrasEngenheiro oe
                 INNER JOIN engenheiros e ON oe.idEngenheiro = e.idEngenheiro
                 INNER JOIN obras o ON oe.idObra = o.idObra
                 ORDER BY o.Descricao ASC, e.dsNome ASC";
$resAlocacoes = mysqli_query($conn, $sqlAlocacoes);

if (!empty($idCombo)) {
    list($idEngenheiroSel, $idObraSel) = explode('_', $idCombo);
    
    $sqlBusca = "SELECT oe.idEngenheiro, oe.idObra, e.dsNome, e.nrCREA, o.Descricao, f.dsFuncao, oe.dtInicioTrabalho, oe.dtFimTrabalho 
                 FROM obrasEngenheiro oe
                 INNER JOIN engenheiros e ON oe.idEngenheiro = e.idEngenheiro
                 INNER JOIN obras o ON oe.idObra = o.idObra
                 LEFT JOIN funcoes f ON oe.idFuncao = f.idFuncao
                 WHERE oe.idEngenheiro = '$idEngenheiroSel' AND oe.idObra = '$idObraSel'";
    $resBusca = mysqli_query($conn, $sqlBusca);
    if ($resBusca && mysqli_num_rows($resBusca) > 0) {
        $alocacaoAtual = mysqli_fetch_assoc($resBusca);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Excluir Alocação</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            background-color: #f1f5f9;
            color: #1e293b;
        }

        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
        }

        .card-header {
            margin-bottom: 24px;
        }

        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 6px;
        }

        p.subtitulo {
            color: #64748b;
            font-size: 14px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 18px;
        }

        label {
            font-size: 14px;
            font-weight: 500;
            color: #334155;
        }

        select {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            color: #1e293b;
            outline: none;
            background-color: #ffffff;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        select:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .alert-danger {
            background-color: #fef2f2;
            border: 1px solid #fecaca;
            color: #991b1b;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            line-height: 1.5;
        }

        .info-box {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
            border-bottom: 1px dashed #e2e8f0;
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #64748b;
            font-weight: 500;
        }

        .info-value {
            color: #1e293b;
            font-weight: 600;
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            justify-content: flex-end;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            border: none;
            transition: background-color 0.2s;
        }

        .btn-danger {
            background-color: #dc2626;
            color: #ffffff;
        }

        .btn-danger:hover {
            background-color: #b91c1c;
        }

        .btn-secondary {
            background-color: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background-color: #e2e8f0;
        }

        .divider {
            height: 1px;
            background-color: #e2e8f0;
            margin: 24px 0;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li><a href="obras.php" class="nav-link">Obras</a></li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li><a href="equipe.php" class="nav-link active">Equipe/Obras</a></li>
            <li><a href="orcamentos.php" class="nav-link">Orçamentos</a></li>
            <li><a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>Excluir Alocação de Equipe</h1>
                <p class="subtitulo">Selecione a alocação que deseja remover do sistema.</p>
            </div>

            <form action="excluirEquipe.php" method="GET">
                <div class="form-group">
                    <label for="idComboSelect">Alocação a excluir</label>
                    <select id="idComboSelect" name="idCombo" onchange="this.form.submit()">
                        <option value="">-- Selecione uma Alocação --</option>
                        <?php 
                        if ($resAlocacoes && mysqli_num_rows($resAlocacoes) > 0) {
                            while ($aloc = mysqli_fetch_assoc($resAlocacoes)) {
                                $val = $aloc['idEngenheiro'] . '_' . $aloc['idObra'];
                                $selected = ($val == $idCombo) ? 'selected' : '';
                                echo "<option value='{$val}' {$selected}>Obra: " . htmlspecialchars($aloc['Descricao']) . " | Eng: " . htmlspecialchars($aloc['dsNome']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </form>

            <?php if ($alocacaoAtual): ?>
                <div class="divider"></div>

                <div class="alert-danger">
                    <strong>Atenção:</strong> Esta ação removerá a alocação do engenheiro nesta obra. Deseja continuar?
                </div>

                <div class="info-box">
                    <div class="info-item">
                        <span class="info-label">Obra:</span>
                        <span class="info-value"><?php echo htmlspecialchars($alocacaoAtual['Descricao']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Engenheiro:</span>
                        <span class="info-value"><?php echo htmlspecialchars($alocacaoAtual['dsNome']); ?> (CREA: <?php echo htmlspecialchars($alocacaoAtual['nrCREA']); ?>)</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Função:</span>
                        <span class="info-value"><?php echo $alocacaoAtual['dsFuncao'] ? htmlspecialchars($alocacaoAtual['dsFuncao']) : 'Não informada'; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Início:</span>
                        <span class="info-value"><?php echo $alocacaoAtual['dtInicioTrabalho'] ? date('d/m/Y', strtotime($alocacaoAtual['dtInicioTrabalho'])) : '-'; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Término:</span>
                        <span class="info-value"><?php echo $alocacaoAtual['dtFimTrabalho'] ? date('d/m/Y', strtotime($alocacaoAtual['dtFimTrabalho'])) : 'Ativo na Obra'; ?></span>
                    </div>
                </div>

                <form action="excluiEquipe.php" method="POST">
                    <input type="hidden" name="idEngenheiro" value="<?php echo $alocacaoAtual['idEngenheiro']; ?>">
                    <input type="hidden" name="idObra" value="<?php echo $alocacaoAtual['idObra']; ?>">

                    <div class="form-actions">
                        <a href="equipe.php" class="btn btn-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-danger">Confirmar Exclusão</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>