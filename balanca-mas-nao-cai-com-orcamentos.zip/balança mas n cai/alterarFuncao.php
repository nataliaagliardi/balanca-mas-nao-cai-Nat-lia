<?php
include_once "sessao.php";
include_once "conexao.php";

$idFuncao = isset($_GET['id']) ? intval($_GET['id']) : 0;
$funcaoAtual = null;

if ($idFuncao > 0) {
    $sqlBusca = "SELECT idFuncao, dsFuncao FROM funcoes WHERE idFuncao = $idFuncao";
    $resBusca = mysqli_query($conn, $sqlBusca);
    if ($resBusca && mysqli_num_rows($resBusca) > 0) {
        $funcaoAtual = mysqli_fetch_assoc($resBusca);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Alterar Função</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            background-color: #f1f5f9;
            color: #1e293b;
        }

        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
            margin-bottom: 24px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            background-color: #f1f5f9;
            color: #475569;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 6px;
            transition: background 0.2s;
        }

        .btn-back:hover {
            background-color: #e2e8f0;
            color: #0f172a;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #334155;
            margin-bottom: 8px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px 14px;
            font-size: 14px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            outline: none;
            transition: border-color 0.2s;
        }

        input[type="text"]:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .btn-submit {
            padding: 10px 20px;
            background-color: #2563eb;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-submit:hover {
            background-color: #1d4ed8;
        }

        .btn-edit {
            padding: 6px 12px;
            background-color: #e0e7ff;
            color: #4338ca;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            border-radius: 4px;
            transition: background 0.2s;
        }

        .btn-edit:hover {
            background-color: #c7d2fe;
        }

        .table-container {
            width: 100%;
            overflow-x: auto;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        thead {
            background-color: #f8fafc;
        }

        th {
            padding: 12px 16px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64748b;
            border-bottom: 1px solid #e2e8f0;
        }

        td {
            padding: 14px 16px;
            font-size: 14px;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 6px;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .alert-success {
            background-color: #dcfce7;
            color: #15803d;
            border: 1px solid #bbf7d0;
        }

        .alert-danger {
            background-color: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li><a href="obras.php" class="nav-link">Obras</a></li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li><a href="funcoes.php" class="nav-link active">Funções</a></li>
            <li><a href="equipe.php" class="nav-link">Equipe/Obras</a></li>
            <li><a href="orcamentos.php" class="nav-link">Orçamentos</a></li>
            <li><a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="header-section">
                <h1>ALTERAR FUNÇÃO</h1>
                <a href="funcoes.php" class="btn-back">← Voltar</a>
            </div>

            <?php if (isset($_GET['status']) && $_GET['status'] == 'sucesso'): ?>
                <div class="alert alert-success">Função atualizada com sucesso!</div>
            <?php elseif (isset($_GET['status']) && $_GET['status'] == 'erro'): ?>
                <div class="alert alert-danger">Erro ao atualizar a função. Tente novamente.</div>
            <?php elseif (isset($_GET['status']) && $_GET['status'] == 'vazio'): ?>
                <div class="alert alert-danger">Por favor, preencha o nome da função.</div>
            <?php endif; ?>

            <?php if ($funcaoAtual): ?>
                <form action="alteraFuncao.php" method="POST">
                    <input type="hidden" name="idFuncao" value="<?php echo $funcaoAtual['idFuncao']; ?>">
                    
                    <div class="form-group">
                        <label for="dsFuncao">Descrição da Função:</label>
                        <input type="text" id="dsFuncao" name="dsFuncao" value="<?php echo htmlspecialchars($funcaoAtual['dsFuncao']); ?>" required>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="submit" class="btn-submit">Salvar Alterações</button>
                        <a href="alterarFuncao.php" class="btn-back">Cancelar</a>
                    </div>
                </form>
            <?php else: ?>
                <p style="color: #64748b; margin-bottom: 16px; font-size: 14px;">Selecione abaixo a função que deseja alterar:</p>
                
                <?php
                $sqlList = "SELECT idFuncao, dsFuncao FROM funcoes ORDER BY idFuncao ASC";
                $resultList = mysqli_query($conn, $sqlList);
                ?>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 80px;">Código</th>
                                <th>Descrição da Função</th>
                                <th style="width: 100px; text-align: center;">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if ($resultList && mysqli_num_rows($resultList) > 0) {
                                while ($row = mysqli_fetch_assoc($resultList)) { 
                            ?>
                                <tr>
                                    <td><strong>#<?php echo $row['idFuncao']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['dsFuncao']); ?></td>
                                    <td style="text-align: center;">
                                        <a href="alterarFuncao.php?id=<?php echo $row['idFuncao']; ?>" class="btn-edit">Editar</a>
                                    </td>
                                </tr>
                            <?php 
                                }
                            } else {
                            ?>
                                <tr>
                                    <td colspan="3" style="text-align: center; color: #94a3b8; padding: 24px;">
                                        Nenhuma função cadastrada para alterar.
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php 
    if (isset($conn) && $conn) {
        mysqli_close($conn); 
    }
    ?>
</body>
</html>