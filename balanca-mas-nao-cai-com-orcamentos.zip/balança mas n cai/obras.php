<?php
include_once "sessao.php";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Obras</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 420px;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
            border: 1px solid #e2e8f0;
            text-align: center;
        }

        .user-welcome {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 24px;
            line-height: 1.4;
        }

        .menu-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .menu-link {
            display: block;
            padding: 12px 20px;
            background-color: #f8fafc;
            color: #334155;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            transition: all 0.2s ease;
        }

        .menu-link:hover {
            background-color: #2563eb;
            color: #ffffff;
            border-color: #2563eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
        }

        .divider {
            height: 1px;
            background-color: #e2e8f0;
            margin: 8px 0;
        }

        .menu-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
            border-color: #fca5a5;
        }

        .menu-link.logout:hover {
            background-color: #dc2626;
            color: #ffffff;
            border-color: #dc2626;
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.15);
        }
    </style>
</head>
<body>

    <div class="card">
        <h2 class="user-welcome">Seja bem-vindo(a),<br><?php echo htmlspecialchars($usuario); ?></h2>

        <ul class="menu-list">
            <li><a href="incluirObra.php" class="menu-link">Inclui Obra</a></li>
            <li><a href="consultaObra.php" class="menu-link">Consulta Obra</a></li>
            <li><a href="alterarObra.php" class="menu-link">Altera Obra</a></li>
            <li><a href="excluirObra.php" class="menu-link">Exclui Obra</a></li>
            
            <div class="divider"></div>
            
            <li><a href="mostra.php" class="menu-link">Voltar ao Menu Principal</a></li>
            <li><a href="logout.php" class="menu-link logout">Sair do Sistema</a></li>
        </ul>
    </div>

</body>
</html>