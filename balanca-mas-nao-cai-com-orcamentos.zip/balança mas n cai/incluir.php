<?php
include_once "sessao.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dsFase = isset($_POST['dsFase']) ? mysqli_real_escape_string($conn, trim($_POST['dsFase'])) : '';

    if (!empty($dsFase)) {
        $sql = "INSERT INTO fases (dsFase) VALUES ('$dsFase')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            mysqli_close($conn);
            header('Location: fases.php?status=sucesso');
            exit;
        } else {
            $erro_msg = "Erro na inclusão do banco de dados: " . mysqli_error($conn);
            mysqli_close($conn);
        }
    } else {
        $erro_msg = "Por favor, preencha o campo Descrição da Fase.";
        mysqli_close($conn);
    }
} else {
    header('Location: fases.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Erro na Inclusão</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 460px;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            border: 1px solid #e2e8f0;
            text-align: center;
        }

        .alert-icon {
            width: 48px;
            height: 48px;
            background-color: #fee2e2;
            color: #dc2626;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: bold;
            margin: 0 auto 16px;
        }

        h2 {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 8px;
        }

        p {
            font-size: 14px;
            color: #64748b;
            margin-bottom: 24px;
            line-height: 1.5;
        }

        .btn-back {
            display: inline-block;
            width: 100%;
            padding: 10px 16px;
            background-color: #2563eb;
            color: #ffffff;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 8px;
            transition: background-color 0.2s;
        }

        .btn-back:hover {
            background-color: #1d4ed8;
        }
    </style>
</head>
<body>

    <div class="card">
        <div class="alert-icon">!</div>
        <h2>Não foi possível concluir a inclusão</h2>
        <p><?php echo htmlspecialchars($erro_msg); ?></p>
        <a href="javascript:history.back()" class="btn-back">Voltar para o formulário</a>
    </div>

</body>
</html>