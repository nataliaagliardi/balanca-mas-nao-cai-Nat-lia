<?php
include_once "sessao.php";
include_once "conexao.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['id'])) {
    $idFuncao = isset($_POST['idFuncao']) ? intval($_POST['idFuncao']) : (isset($_GET['id']) ? intval($_GET['id']) : 0);

    if ($idFuncao > 0) {
        $sql = "DELETE FROM funcoes WHERE idFuncao = $idFuncao";

        try {
            if (mysqli_query($conn, $sql)) {
                header("Location: excluirFuncao.php?status=sucesso");
                exit;
            } else {
                header("Location: excluirFuncao.php?status=erro");
                exit;
            }
        } catch (mysqli_sql_exception $e) {
            header("Location: excluirFuncao.php?status=erro_fk");
            exit;
        }
    } else {
        header("Location: excluirFuncao.php?status=erro");
        exit;
    }
} else {
    header("Location: excluirFuncao.php");
    exit;
}
?>