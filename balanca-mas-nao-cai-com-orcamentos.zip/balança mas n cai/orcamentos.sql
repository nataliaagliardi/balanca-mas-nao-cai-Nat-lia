CREATE TABLE IF NOT EXISTS orcamentos (
    idOrcamento INT AUTO_INCREMENT PRIMARY KEY,
    idObra INT NOT NULL,
    idFase INT NULL,
    dtOrcamento DATE NOT NULL,
    vlOrcamento DECIMAL(12, 2) NOT NULL,
    dsObservacao VARCHAR(255) NULL,
    CONSTRAINT fk_orcamentos_obra FOREIGN KEY (idObra) REFERENCES obras(idObra),
    CONSTRAINT fk_orcamentos_fase FOREIGN KEY (idFase) REFERENCES fases(idFase)
);
