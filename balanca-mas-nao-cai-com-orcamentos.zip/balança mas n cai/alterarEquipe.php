<?php
include_once "sessao.php";
include_once "conexao.php"; 

$sql = "SELECT 
            oe.idObra,
            oe.idEngenheiro,
            e.dsNome AS nome_engenheiro,
            e.nrCREA,
            o.Descricao AS nome_obra,
            f.dsFuncao AS nome_funcao,
            oe.dtInicioTrabalho,
            oe.dtFimTrabalho
        FROM obrasEngenheiro oe
        INNER JOIN engenheiros e ON oe.idEngenheiro = e.idEngenheiro
        INNER JOIN obras o ON oe.idObra = o.idObra
        LEFT JOIN funcoes f ON oe.idFuncao = f.idFuncao
        ORDER BY o.Descricao ASC, e.dsNome ASC";

$resultado = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Alterar Alocação</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 860px;
            padding: 36px;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
            border: 1px solid #e2e8f0;
        }

        .header-title {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            text-align: center;
        }

        .alert-success {
            background-color: #dcfce7;
            color: #166534;
            border: 1px solid #86efac;
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 20px;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
            font-size: 14px;
        }

        th, td {
            padding: 12px 14px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            color: #334155;
        }

        th {
            background-color: #f8fafc;
            font-weight: 600;
            color: #1e293b;
        }

        tr:hover td {
            background-color: #f8fafc;
        }

        .btn-edit {
            display: inline-block;
            padding: 6px 14px;
            background-color: #2563eb;
            color: #ffffff;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            border-radius: 6px;
            transition: background-color 0.2s ease;
        }

        .btn-edit:hover {
            background-color: #1d4ed8;
        }

        .btn-back {
            display: block;
            width: 100%;
            padding: 12px 20px;
            background-color: #f8fafc;
            color: #334155;
            text-align: center;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            transition: all 0.2s ease;
        }

        .btn-back:hover {
            background-color: #e2e8f0;
            color: #1e293b;
        }

        .empty-msg {
            text-align: center;
            color: #64748b;
            padding: 24px 0;
            font-size: 14px;
        }
    </style>
</head>
<body>

    <div class="card">
        <h2 class="header-title">Selecione a Alocação para Alterar</h2>

        <?php if (isset($_GET['sucesso'])): ?>
            <div class="alert-success">Alocação atualizada com sucesso!</div>
        <?php endif; ?>

        <?php if ($resultado && $resultado->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Obra</th>
                        <th>Engenheiro</th>
                        <th>Função</th>
                        <th>Início</th>
                        <th>Término</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['nome_obra']); ?></td>
                            <td><?php echo htmlspecialchars($row['nome_engenheiro']); ?> (CREA: <?php echo htmlspecialchars($row['nrCREA']); ?>)</td>
                            <td><?php echo htmlspecialchars($row['nome_funcao'] ?? 'Não informada'); ?></td>
                            <td><?php echo $row['dtInicioTrabalho'] ? date('d/m/Y', strtotime($row['dtInicioTrabalho'])) : '-'; ?></td>
                            <td><?php echo $row['dtFimTrabalho'] ? date('d/m/Y', strtotime($row['dtFimTrabalho'])) : 'Ativo'; ?></td>
                            <td>
                                <a href="alteraEquipe.php?idObra=<?php echo (int)$row['idObra']; ?>&idEngenheiro=<?php echo (int)$row['idEngenheiro']; ?>" class="btn-edit">
                                    Alterar
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="empty-msg">Nenhuma alocação encontrada no sistema.</p>
        <?php endif; ?>

        <a href="equipe.php" class="btn-back">Voltar ao Menu de Equipes</a>
    </div>

</body>
</html>
