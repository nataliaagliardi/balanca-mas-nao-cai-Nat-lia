<?php
include_once "sessao.php";
include_once "conexao.php";

$idOrcamentoSelecionado = isset($_REQUEST['idOrcamento']) ? (int)$_REQUEST['idOrcamento'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);
$orcamentoAtual = null;

$sqlOrcamentos = "SELECT orc.idOrcamento, ob.Descricao AS nomeObra, f.dsFase AS nomeFase, orc.vlOrcamento
                  FROM orcamentos orc
                  INNER JOIN obras ob ON orc.idObra = ob.idObra
                  LEFT JOIN fases f ON orc.idFase = f.idFase
                  ORDER BY orc.idOrcamento DESC";
$resultOrcamentos = mysqli_query($conn, $sqlOrcamentos);

if ($idOrcamentoSelecionado > 0) {
    $sqlBusca = "SELECT orc.idOrcamento, ob.Descricao AS nomeObra, f.dsFase AS nomeFase, orc.dtOrcamento, orc.vlOrcamento, orc.dsObservacao 
                 FROM orcamentos orc
                 INNER JOIN obras ob ON orc.idObra = ob.idObra
                 LEFT JOIN fases f ON orc.idFase = f.idFase
                 WHERE orc.idOrcamento = $idOrcamentoSelecionado";
    $resBusca = mysqli_query($conn, $sqlBusca);
    if ($resBusca && mysqli_num_rows($resBusca) > 0) {
        $orcamentoAtual = mysqli_fetch_assoc($resBusca);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Excluir Orçamento</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            background-color: #f1f5f9;
            color: #1e293b;
        }

        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
        }

        .card-header {
            margin-bottom: 24px;
        }

        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 6px;
        }

        p.subtitulo {
            color: #64748b;
            font-size: 14px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 18px;
        }

        label {
            font-size: 14px;
            font-weight: 500;
            color: #334155;
        }

        select {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            color: #1e293b;
            outline: none;
            background-color: #ffffff;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        select:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .alert-danger {
            background-color: #fef2f2;
            border: 1px solid #fecaca;
            color: #991b1b;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            line-height: 1.5;
        }

        .info-box {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
        }

        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 14px;
            border-bottom: 1px dashed #e2e8f0;
            gap: 12px;
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-label {
            color: #64748b;
            font-weight: 500;
        }

        .info-value {
            color: #1e293b;
            font-weight: 600;
            text-align: right;
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            justify-content: flex-end;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            border: none;
            transition: background-color 0.2s;
        }

        .btn-danger {
            background-color: #dc2626;
            color: #ffffff;
        }

        .btn-danger:hover {
            background-color: #b91c1c;
        }

        .btn-secondary {
            background-color: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background-color: #e2e8f0;
        }

        .divider {
            height: 1px;
            background-color: #e2e8f0;
            margin: 24px 0;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li><a href="obras.php" class="nav-link">Obras</a></li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li><a href="equipe.php" class="nav-link">Equipe/Obras</a></li>
            <li><a href="orcamentos.php" class="nav-link active">Orçamentos</a></li>
            <li><a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>Excluir Orçamento</h1>
                <p class="subtitulo">Selecione o orçamento que deseja remover do sistema.</p>
            </div>

            <form action="excluirOrcamento.php" method="GET">
                <div class="form-group">
                    <label for="idOrcamentoSelect">Orçamento a excluir</label>
                    <select id="idOrcamentoSelect" name="idOrcamento" onchange="this.form.submit()">
                        <option value="">-- Selecione um Orçamento --</option>
                        <?php 
                        if ($resultOrcamentos && mysqli_num_rows($resultOrcamentos) > 0) {
                            while ($orc = mysqli_fetch_assoc($resultOrcamentos)) {
                                $selected = ($orc['idOrcamento'] == $idOrcamentoSelecionado) ? 'selected' : '';
                                $faseLabel = $orc['nomeFase'] ? " - " . $orc['nomeFase'] : "";
                                $valorLabel = 'R$ ' . number_format((float)$orc['vlOrcamento'], 2, ',', '.');
                                echo "<option value='{$orc['idOrcamento']}' {$selected}>#{$orc['idOrcamento']} - " . htmlspecialchars($orc['nomeObra'] . $faseLabel) . " ($valorLabel)</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </form>

            <?php if ($orcamentoAtual): ?>
                <div class="divider"></div>

                <div class="alert-danger">
                    <strong>Atenção:</strong> Esta ação não poderá ser desfeita. Tem certeza de que deseja remover permanentemente este orçamento?
                </div>

                <div class="info-box">
                    <div class="info-item">
                        <span class="info-label">Código:</span>
                        <span class="info-value">#<?php echo $orcamentoAtual['idOrcamento']; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Obra:</span>
                        <span class="info-value"><?php echo htmlspecialchars($orcamentoAtual['nomeObra']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Fase:</span>
                        <span class="info-value"><?php echo $orcamentoAtual['nomeFase'] ? htmlspecialchars($orcamentoAtual['nomeFase']) : 'Geral'; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Data:</span>
                        <span class="info-value"><?php echo $orcamentoAtual['dtOrcamento'] ? date('d/m/Y', strtotime($orcamentoAtual['dtOrcamento'])) : '-'; ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Valor Orçado:</span>
                        <span class="info-value">R$ <?php echo number_format((float)$orcamentoAtual['vlOrcamento'], 2, ',', '.'); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Observação:</span>
                        <span class="info-value"><?php echo !empty($orcamentoAtual['dsObservacao']) ? htmlspecialchars($orcamentoAtual['dsObservacao']) : '-'; ?></span>
                    </div>
                </div>

                <form action="excluiOrcamento.php" method="POST">
                    <input type="hidden" name="idOrcamento" value="<?php echo $orcamentoAtual['idOrcamento']; ?>">

                    <div class="form-actions">
                        <a href="orcamentos.php" class="btn btn-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-danger">Confirmar Exclusão</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>
