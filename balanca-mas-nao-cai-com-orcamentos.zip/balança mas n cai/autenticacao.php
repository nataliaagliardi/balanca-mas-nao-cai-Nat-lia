<?php
	session_start();

	try {
		$usuario = $_POST['usuario'];
		$senha = $_POST['senha'];

		include_once "conexao.php";

		$conn = mysqli_connect($localhost, $user, $password, $banco);

		if (!$conn) {
			header('Location: index.html');
		}
	
		$sql = "SELECT * FROM usuarios WHERE (Email='$usuario') AND (Senha='$password')";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_num_rows($result);

		if ($row > 0) {
			while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
				$usuario = $row["Nome"];
				$email = $row["Email"];
				$senha = $row["Senha"];
			}

			$_SESSION['usuario'] = $usuario;
			$_SESSION['dsEmail'] = $email;
			$_SESSION['senha'] = $senha;

			header('Location: mostra.php');
		} else {
			header('Location: index.html');
		}
	} catch (Exception $e) {
		header('Location: index.html');
	}
?>