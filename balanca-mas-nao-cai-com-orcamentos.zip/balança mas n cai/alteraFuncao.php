<?php
include_once "sessao.php";
include_once "conexao.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idFuncao = isset($_POST['idFuncao']) ? intval($_POST['idFuncao']) : 0;
    $dsFuncao = isset($_POST['dsFuncao']) ? trim($_POST['dsFuncao']) : '';

    if ($idFuncao > 0 && !empty($dsFuncao)) {
        $dsFuncaoSanitizada = mysqli_real_escape_string($conn, $dsFuncao);

        $sql = "UPDATE funcoes SET dsFuncao = '$dsFuncaoSanitizada' WHERE idFuncao = $idFuncao";

        if (mysqli_query($conn, $sql)) {
            header("Location: alterarFuncao.php?status=sucesso");
            exit;
        } else {
            header("Location: alterarFuncao.php?id=$idFuncao&status=erro");
            exit;
        }
    } else {
        header("Location: alterarFuncao.php?id=$idFuncao&status=vazio");
        exit;
    }
} else {
    header("Location: alterarFuncao.php");
    exit;
}
?>