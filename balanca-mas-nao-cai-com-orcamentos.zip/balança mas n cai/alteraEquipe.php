<?php
include_once "sessao.php";
include_once "conexao.php"; 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $origIdObra       = (int) $_POST['orig_idObra'];
    $origIdEngenheiro = (int) $_POST['orig_idEngenheiro'];
    $idObra           = (int) $_POST['idObra'];
    $idEngenheiro     = (int) $_POST['idEngenheiro'];
    $idFuncao         = (int) $_POST['idFuncao'];
    $dtInicioTrabalho = trim($_POST['dtInicioTrabalho'] ?? '');
    $dtFimTrabalho    = trim($_POST['dtFimTrabalho'] ?? '');
    $dtFimVal         = !empty($dtFimTrabalho) ? $dtFimTrabalho : null;

    $stmtEng = $conn->prepare("SELECT dtAdmissao FROM engenheiros WHERE idEngenheiro = ?");
    $stmtEng->bind_param("i", $idEngenheiro);
    $stmtEng->execute();
    $resEng = $stmtEng->get_result();
    $engData = $resEng ? $resEng->fetch_assoc() : null;
    $stmtEng->close();
    $dtAdmissaoEngenheiro = $engData['dtAdmissao'] ?? null;

    $stmt = $conn->prepare("UPDATE obrasEngenheiro 
                            SET idObra = ?, idEngenheiro = ?, dtAdmissaoEngenheiro = ?, dtInicioTrabalho = ?, dtFimTrabalho = ?, idFuncao = ? 
                            WHERE idObra = ? AND idEngenheiro = ?");
    $stmt->bind_param("iisssiii", $idObra, $idEngenheiro, $dtAdmissaoEngenheiro, $dtInicioTrabalho, $dtFimVal, $idFuncao, $origIdObra, $origIdEngenheiro);

    if ($stmt->execute()) {
        header("Location: alterarEquipe.php?sucesso=1");
        exit;
    } else {
        $erro = "Erro ao atualizar alocação: " . $conn->error;
    }
    $stmt->close();
}

$idObraGet       = isset($_REQUEST['idObra']) ? (int) $_REQUEST['idObra'] : 0;
$idEngenheiroGet = isset($_REQUEST['idEngenheiro']) ? (int) $_REQUEST['idEngenheiro'] : 0;

if ($idObraGet <= 0 || $idEngenheiroGet <= 0) {
    header("Location: alterarEquipe.php");
    exit;
}

$stmt = $conn->prepare("SELECT idObra, idEngenheiro, dtAdmissaoEngenheiro, dtInicioTrabalho, dtFimTrabalho, idFuncao 
                        FROM obrasEngenheiro 
                        WHERE idObra = ? AND idEngenheiro = ?");
$stmt->bind_param("ii", $idObraGet, $idEngenheiroGet);
$stmt->execute();
$alocacao = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$alocacao) {
    header("Location: alterarEquipe.php");
    exit;
}

$engenheiros = $conn->query("SELECT idEngenheiro, dsNome, nrCREA FROM engenheiros ORDER BY dsNome ASC");
$obras       = $conn->query("SELECT idObra, Descricao FROM obras ORDER BY Descricao ASC");
$funcoes     = $conn->query("SELECT idFuncao, dsFuncao FROM funcoes ORDER BY dsFuncao ASC");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Editar Alocação</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 480px;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
            border: 1px solid #e2e8f0;
        }

        .header-title {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 24px;
            text-align: center;
        }

        .alert-error {
            background-color: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fca5a5;
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
            margin-bottom: 16px;
        }

        .form-group {
            margin-bottom: 16px;
            text-align: left;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #334155;
            margin-bottom: 6px;
        }

        select, input[type="date"] {
            width: 100%;
            padding: 11px 14px;
            font-size: 14px;
            color: #1e293b;
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            outline: none;
            transition: border-color 0.2s ease;
        }

        select:focus, input[type="date"]:focus {
            border-color: #2563eb;
            background-color: #ffffff;
        }

        .btn-submit {
            width: 100%;
            padding: 12px 20px;
            background-color: #2563eb;
            color: #ffffff;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 8px;
            transition: all 0.2s ease;
        }

        .btn-submit:hover {
            background-color: #1d4ed8;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
        }

        .btn-cancel {
            display: block;
            width: 100%;
            padding: 12px 20px;
            margin-top: 10px;
            background-color: #f8fafc;
            color: #334155;
            text-align: center;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            transition: all 0.2s ease;
        }

        .btn-cancel:hover {
            background-color: #e2e8f0;
            color: #1e293b;
        }
    </style>
</head>
<body>

    <div class="card">
        <h2 class="header-title">Alterar Alocação</h2>

        <?php if (isset($erro)): ?>
            <div class="alert-error"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>

        <form method="POST" action="alteraEquipe.php?idObra=<?php echo (int)$alocacao['idObra']; ?>&idEngenheiro=<?php echo (int)$alocacao['idEngenheiro']; ?>">
            <input type="hidden" name="orig_idObra" value="<?php echo (int)$alocacao['idObra']; ?>">
            <input type="hidden" name="orig_idEngenheiro" value="<?php echo (int)$alocacao['idEngenheiro']; ?>">

            <div class="form-group">
                <label for="idObra">Obra</label>
                <select name="idObra" id="idObra" required>
                    <?php while ($obra = $obras->fetch_assoc()): ?>
                        <option value="<?php echo (int)$obra['idObra']; ?>"
                            <?php echo ($obra['idObra'] == $alocacao['idObra']) ? 'selected' : ''; ?>>
                            #<?php echo (int)$obra['idObra']; ?> - <?php echo htmlspecialchars($obra['Descricao']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="idEngenheiro">Engenheiro</label>
                <select name="idEngenheiro" id="idEngenheiro" required>
                    <?php while ($eng = $engenheiros->fetch_assoc()): ?>
                        <option value="<?php echo (int)$eng['idEngenheiro']; ?>"
                            <?php echo ($eng['idEngenheiro'] == $alocacao['idEngenheiro']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($eng['dsNome']); ?> (CREA: <?php echo htmlspecialchars($eng['nrCREA']); ?>)
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="idFuncao">Função na Obra</label>
                <select name="idFuncao" id="idFuncao" required>
                    <?php while ($func = $funcoes->fetch_assoc()): ?>
                        <option value="<?php echo (int)$func['idFuncao']; ?>"
                            <?php echo ($func['idFuncao'] == $alocacao['idFuncao']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($func['dsFuncao']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="dtInicioTrabalho">Data de Início das Atividades</label>
                <input type="date" name="dtInicioTrabalho" id="dtInicioTrabalho"
                       value="<?php echo htmlspecialchars($alocacao['dtInicioTrabalho'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label for="dtFimTrabalho">Data de Término (se houver)</label>
                <input type="date" name="dtFimTrabalho" id="dtFimTrabalho"
                       value="<?php echo htmlspecialchars($alocacao['dtFimTrabalho'] ?? ''); ?>">
            </div>

            <button type="submit" class="btn-submit">Salvar Alterações</button>
            <a href="alterarEquipe.php" class="btn-cancel">Cancelar</a>
        </form>
    </div>

</body>
</html>
