<?php
include_once "sessao.php";
include_once "conexao.php";

$idObraSelecionada = $_REQUEST['idObra'] ?? $_GET['id'] ?? '';
$obraAtual = null;

$sqlObras = "SELECT idObra, Descricao FROM obras ORDER BY Descricao ASC";
$resultObras = mysqli_query($conn, $sqlObras);

$sqlEngenheiros = "SELECT idEngenheiro, dsNome, nrCREA FROM engenheiros ORDER BY dsNome ASC";
$resultEngenheiros = mysqli_query($conn, $sqlEngenheiros);

if (!empty($idObraSelecionada)) {
    $sqlBusca = "SELECT idObra, Descricao, dtInicio, dtFim, idEngenheiro FROM obras WHERE idObra = '$idObraSelecionada'";
    $resBusca = mysqli_query($conn, $sqlBusca);
    if ($resBusca && mysqli_num_rows($resBusca) > 0) {
        $obraAtual = mysqli_fetch_assoc($resBusca);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Altera Obra</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            background-color: #f1f5f9;
            color: #1e293b;
        }

        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
        }

        .card-header {
            margin-bottom: 24px;
        }

        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 6px;
        }

        p.subtitulo {
            color: #64748b;
            font-size: 14px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 18px;
        }

        label {
            font-size: 14px;
            font-weight: 500;
            color: #334155;
        }

        input[type="text"],
        input[type="date"],
        select {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            color: #1e293b;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s;
            background-color: #ffffff;
        }

        input[type="text"]:focus,
        input[type="date"]:focus,
        select:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            justify-content: flex-end;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            border: none;
            transition: background-color 0.2s;
        }

        .btn-primary {
            background-color: #2563eb;
            color: #ffffff;
        }

        .btn-primary:hover {
            background-color: #1d4ed8;
        }

        .btn-secondary {
            background-color: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background-color: #e2e8f0;
        }

        .divider {
            height: 1px;
            background-color: #e2e8f0;
            margin: 24px 0;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li><a href="obras.php" class="nav-link active">Obras</a></li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li><a href="equipe.php" class="nav-link">Equipe/Obras</a></li>
            <li><a href="orcamentos.php" class="nav-link">Orçamentos</a></li>
            <li><a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>Alterar Obra</h1>
                <p class="subtitulo">Selecione a obra para carregar os dados e efetuar as alterações necessárias.</p>
            </div>

            <form action="alterarObra.php" method="GET">
                <div class="form-group">
                    <label for="idObraSelect">Obra a alterar</label>
                    <select id="idObraSelect" name="idObra" onchange="this.form.submit()">
                        <option value="">Selecione uma Obra</option>
                        <?php 
                        if ($resultObras && mysqli_num_rows($resultObras) > 0) {
                            while ($obra = mysqli_fetch_assoc($resultObras)) {
                                $selected = ($obra['idObra'] == $idObraSelecionada) ? 'selected' : '';
                                echo "<option value='{$obra['idObra']}' {$selected}>#{$obra['idObra']} - " . htmlspecialchars($obra['Descricao']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </form>

            <?php if ($obraAtual): ?>
                <div class="divider"></div>

                <form action="alteraObra.php" method="POST">
                    <input type="hidden" name="idObra" value="<?php echo $obraAtual['idObra']; ?>">

                    <div class="form-group">
                        <label for="Descricao">Descrição / Nome da Obra</label>
                        <input type="text" id="Descricao" name="Descricao" maxlength="150" value="<?php echo htmlspecialchars($obraAtual['Descricao']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="dtInicio">Data de Início</label>
                        <input type="date" id="dtInicio" name="dtInicio" value="<?php echo $obraAtual['dtInicio']; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="dtFim">Data de Término (Prevista/Real)</label>
                        <input type="date" id="dtFim" name="dtFim" value="<?php echo $obraAtual['dtFim']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="idEngenheiro">Engenheiro Responsável Técnico</label>
                        <select id="idEngenheiro" name="idEngenheiro" required>
                            <option value="">-- Selecione o Engenheiro Responsável --</option>
                            <?php 
                            if ($resultEngenheiros && mysqli_num_rows($resultEngenheiros) > 0) {
                                mysqli_data_seek($resultEngenheiros, 0);
                                while ($eng = mysqli_fetch_assoc($resultEngenheiros)) {
                                    $selectedEng = ($eng['idEngenheiro'] == $obraAtual['idEngenheiro']) ? 'selected' : '';
                                    echo "<option value='{$eng['idEngenheiro']}' {$selectedEng}>" . htmlspecialchars($eng['dsNome']) . " (CREA: " . htmlspecialchars($eng['nrCREA']) . ")</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-actions">
                        <a href="obras.php" class="btn btn-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-primary">Atualizar Obra</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>