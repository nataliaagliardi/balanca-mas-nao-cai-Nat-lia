<?php
include_once "sessao.php";
include_once "conexao.php";

$idFuncao = isset($_GET['id']) ? intval($_GET['id']) : 0;
$funcaoExcluir = null;

if ($idFuncao > 0) {
    $sqlBusca = "SELECT idFuncao, dsFuncao FROM funcoes WHERE idFuncao = $idFuncao";
    $resBusca = mysqli_query($conn, $sqlBusca);
    if ($resBusca && mysqli_num_rows($resBusca) > 0) {
        $funcaoExcluir = mysqli_fetch_assoc($resBusca);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Excluir Função</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            background-color: #f1f5f9;
            color: #1e293b;
        }

        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
            margin-bottom: 24px;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            background-color: #f1f5f9;
            color: #475569;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 6px;
            transition: background 0.2s;
        }

        .btn-back:hover {
            background-color: #e2e8f0;
            color: #0f172a;
        }

        .confirm-box {
            background-color: #fff1f2;
            border: 1px solid #fecdd3;
            border-radius: 8px;
            padding: 24px;
            margin-bottom: 24px;
        }

        .confirm-title {
            color: #991b1b;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .confirm-text {
            color: #7f1d1d;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .btn-delete-confirm {
            padding: 10px 20px;
            background-color: #dc2626;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-delete-confirm:hover {
            background-color: #b91c1c;
        }

        .btn-delete {
            padding: 6px 12px;
            background-color: #fee2e2;
            color: #b91c1c;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            border-radius: 4px;
            transition: all 0.2s;
        }

        .btn-delete:hover {
            background-color: #dc2626;
            color: #ffffff;
        }

        .table-container {
            width: 100%;
            overflow-x: auto;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        thead {
            background-color: #f8fafc;
        }

        th {
            padding: 12px 16px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64748b;
            border-bottom: 1px solid #e2e8f0;
        }

        td {
            padding: 14px 16px;
            font-size: 14px;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 6px;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .alert-success {
            background-color: #dcfce7;
            color: #15803d;
            border: 1px solid #bbf7d0;
        }

        .alert-danger {
            background-color: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li><a href="obras.php" class="nav-link">Obras</a></li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li><a href="funcoes.php" class="nav-link active">Funções</a></li>
            <li><a href="equipe.php" class="nav-link">Equipe/Obras</a></li>
            <li><a href="orcamentos.php" class="nav-link">Orçamentos</a></li>
            <li><a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="header-section">
                <h1>EXCLUIR FUNÇÃO</h1>
                <a href="funcoes.php" class="btn-back">← Voltar</a>
            </div>

            <?php if (isset($_GET['status']) && $_GET['status'] == 'sucesso'): ?>
                <div class="alert alert-success">Função excluída com sucesso!</div>
            <?php elseif (isset($_GET['status']) && $_GET['status'] == 'erro_fk'): ?>
                <div class="alert alert-danger">Não é possível excluir esta função pois ela está associada a engenheiros em obras cadastradas.</div>
            <?php elseif (isset($_GET['status']) && $_GET['status'] == 'erro'): ?>
                <div class="alert alert-danger">Erro ao tentar excluir a função. Tente novamente.</div>
            <?php endif; ?>

            <?php if ($funcaoExcluir): ?>
                <div class="confirm-box">
                    <div class="confirm-title">Atenção: Confirmação de Exclusão</div>
                    <div class="confirm-text">
                        Tem certeza que deseja excluir permanentemente a função <strong>"<?php echo htmlspecialchars($funcaoExcluir['dsFuncao']); ?>"</strong> (Código #<?php echo $funcaoExcluir['idFuncao']; ?>)?
                    </div>
                    
                    <form action="excluiFuncao.php" method="POST" style="display: flex; gap: 10px;">
                        <input type="hidden" name="idFuncao" value="<?php echo $funcaoExcluir['idFuncao']; ?>">
                        <button type="submit" class="btn-delete-confirm">Sim, Excluir</button>
                        <a href="excluirFuncao.php" class="btn-back">Cancelar</a>
                    </form>
                </div>
            <?php else: ?>
                <p style="color: #64748b; margin-bottom: 16px; font-size: 14px;">Selecione abaixo a função que deseja remover:</p>
                
                <?php
                $sqlList = "SELECT idFuncao, dsFuncao FROM funcoes ORDER BY idFuncao ASC";
                $resultList = mysqli_query($conn, $sqlList);
                ?>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 80px;">Código</th>
                                <th>Descrição da Função</th>
                                <th style="width: 100px; text-align: center;">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if ($resultList && mysqli_num_rows($resultList) > 0) {
                                while ($row = mysqli_fetch_assoc($resultList)) { 
                            ?>
                                <tr>
                                    <td><strong>#<?php echo $row['idFuncao']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['dsFuncao']); ?></td>
                                    <td style="text-align: center;">
                                        <a href="excluirFuncao.php?id=<?php echo $row['idFuncao']; ?>" class="btn-delete">Excluir</a>
                                    </td>
                                </tr>
                            <?php 
                                }
                            } else {
                            ?>
                                <tr>
                                    <td colspan="3" style="text-align: center; color: #94a3b8; padding: 24px;">
                                        Nenhuma função encontrada para exclusão.
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php 
    if (isset($conn) && $conn) {
        mysqli_close($conn); 
    }
    ?>
</body>
</html>