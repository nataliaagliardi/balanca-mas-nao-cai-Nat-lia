<?php
include_once "sessao.php";
include_once "conexao.php";

$filtroObra = isset($_GET['idObra']) ? (int)$_GET['idObra'] : 0;

$sqlObrasFiltro = "SELECT idObra, Descricao FROM obras ORDER BY Descricao ASC";
$resObrasFiltro = mysqli_query($conn, $sqlObrasFiltro);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Consulta de Orçamentos</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            background-color: #f1f5f9;
            color: #1e293b;
        }

        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 1080px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            gap: 16px;
            flex-wrap: wrap;
        }

        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
        }

        .filter-bar {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-bar label {
            font-size: 14px;
            font-weight: 500;
            color: #475569;
        }

        .filter-bar select {
            padding: 8px 12px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            color: #1e293b;
            background-color: #ffffff;
            min-width: 260px;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            background-color: #f1f5f9;
            color: #475569;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            border-radius: 6px;
            transition: background 0.2s;
        }

        .btn-back:hover {
            background-color: #e2e8f0;
            color: #0f172a;
        }

        .table-container {
            width: 100%;
            overflow-x: auto;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        thead {
            background-color: #f8fafc;
        }

        th {
            padding: 12px 16px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #64748b;
            border-bottom: 1px solid #e2e8f0;
        }

        td {
            padding: 14px 16px;
            font-size: 14px;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }

        tbody tr:last-child td {
            border-bottom: none;
        }

        tbody tr:hover {
            background-color: #f8fafc;
        }

        tfoot tr {
            background-color: #f8fafc;
            border-top: 2px solid #e2e8f0;
        }

        tfoot td {
            font-weight: 600;
            color: #1e293b;
            padding: 14px 16px;
        }

        .badge {
            display: inline-block;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 500;
            color: #2563eb;
            background-color: #eff6ff;
            border-radius: 4px;
        }

        .valor-orcado {
            font-weight: 600;
            color: #0f172a;
            white-space: nowrap;
        }

        .text-muted {
            color: #94a3b8;
            font-style: italic;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li><a href="obras.php" class="nav-link">Obras</a></li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li><a href="equipe.php" class="nav-link">Equipe/Obras</a></li>
            <li><a href="orcamentos.php" class="nav-link active">Orçamentos</a></li>
            <li><a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="header-section">
                <h1>CONSULTA DE ORÇAMENTOS</h1>
                <a href="orcamentos.php" class="btn-back">← Voltar</a>
            </div>

            <form method="GET" action="consultaOrcamento.php" class="filter-bar">
                <label for="idObraFiltro">Filtrar por Obra:</label>
                <select id="idObraFiltro" name="idObra" onchange="this.form.submit()">
                    <option value="0">Todas as Obras</option>
                    <?php 
                    if ($resObrasFiltro && mysqli_num_rows($resObrasFiltro) > 0) {
                        while ($ob = mysqli_fetch_assoc($resObrasFiltro)) {
                            $sel = ($ob['idObra'] == $filtroObra) ? 'selected' : '';
                            echo "<option value='{$ob['idObra']}' {$sel}>#{$ob['idObra']} - " . htmlspecialchars($ob['Descricao']) . "</option>";
                        }
                    }
                    ?>
                </select>
            </form>

            <?php
            $where = ($filtroObra > 0) ? "WHERE orc.idObra = $filtroObra" : "";
            $sql = "SELECT 
                        orc.idOrcamento, 
                        ob.Descricao, 
                        f.dsFase, 
                        orc.dtOrcamento, 
                        orc.vlOrcamento, 
                        orc.dsObservacao
                    FROM orcamentos orc
                    INNER JOIN obras ob ON orc.idObra = ob.idObra
                    LEFT JOIN fases f ON orc.idFase = f.idFase
                    $where
                    ORDER BY orc.dtOrcamento DESC, orc.idOrcamento DESC";
            $result = mysqli_query($conn, $sql);
            $totalGeral = 0.0;
            ?>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Obra</th>
                            <th>Fase</th>
                            <th>Data</th>
                            <th>Valor Orçado</th>
                            <th>Observação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) { 
                                $dtOrcamento = $row[3] ? date('d/m/Y', strtotime($row[3])) : '-';
                                $valor = (float)$row[4];
                                $totalGeral += $valor;
                                $valorFormatado = 'R$ ' . number_format($valor, 2, ',', '.');
                                $faseNome = $row[2] ? htmlspecialchars($row[2]) : '<span class="text-muted">Geral</span>';
                                $obs = !empty($row[5]) ? htmlspecialchars($row[5]) : '<span class="text-muted">-</span>';
                        ?>
                            <tr>
                                <td><span class="badge">#<?php echo htmlspecialchars($row[0]); ?></span></td>
                                <td><strong><?php echo htmlspecialchars($row[1]); ?></strong></td>
                                <td><?php echo $faseNome; ?></td>
                                <td><?php echo $dtOrcamento; ?></td>
                                <td class="valor-orcado"><?php echo $valorFormatado; ?></td>
                                <td><?php echo $obs; ?></td>
                            </tr>
                        <?php 
                            }
                        } else {
                        ?>
                            <tr>
                                <td colspan="6" style="text-align: center; color: #94a3b8; padding: 24px;">
                                    Nenhum orçamento cadastrado.
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                    <tfoot>
                        <tr>
                            <td colspan="4" style="text-align: right;">Total Orçado:</td>
                            <td colspan="2" class="valor-orcado" style="color: #2563eb;">
                                R$ <?php echo number_format($totalGeral, 2, ',', '.'); ?>
                            </td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <?php 
    if (isset($conn) && $conn) {
        mysqli_close($conn); 
    }
    ?>
</body>
</html>
