<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Balança mas não cai - Menu Principal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

		.navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            background-color: #f1f5f9;
            color: #1e293b;
        }


        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .bemVindo {
            background: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
        }

        h1 {
            color: #1e293b;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        p {
            color: #64748b;
            font-size: 14px;
            line-height: 1.5;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Página inicial</a></li>
            <li><a href="obras.php" class="nav-link">Obras</a></li>
            <li> <a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li> <a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li> <a href="equipe.php" class="nav-link">Equipe</a></li>
            <li> <a href="funcoes.php" class="nav-link">Funções</a></li>
            <li> <a href="orcamentos.php" class="nav-link">Orçamentos</a></li>
            <li> <a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="bemVindo">
            <h1>Bem-vindo ao Sistema</h1>
            <p>Utilize o menu acima para navegar entre as seções do sistema e realizar o controle das obras, engenheiros e fases de execução.</p>
        </div>
    </div>

</body>
</html>