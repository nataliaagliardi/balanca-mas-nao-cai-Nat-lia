<?php
include_once "sessao.php";
include_once "conexao.php";

$sqlEng = "SELECT idEngenheiro, dsNome, nrCREA FROM engenheiros ORDER BY dsNome ASC";
$resEng = mysqli_query($conn, $sqlEng);

$sqlObras = "SELECT idObra, Descricao FROM obras ORDER BY Descricao ASC";
$resObras = mysqli_query($conn, $sqlObras);

$sqlFunc = "SELECT idFuncao, dsFuncao FROM funcoes ORDER BY dsFuncao ASC";
$resFunc = mysqli_query($conn, $sqlFunc);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Balança mas não cai - Alocar Engenheiro</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .navMarca {
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
            text-decoration: none;
        }

        .nav {
            list-style: none;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .nav-link {
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #475569;
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            background-color: #f1f5f9;
            color: #1e293b;
        }

        .nav-link.logout {
            background-color: #fee2e2;
            color: #b91c1c;
        }

        .nav-link.logout:hover {
            background-color: #fecaca;
            color: #991b1b;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .card {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            border: 1px solid #e2e8f0;
        }

        .card-header {
            margin-bottom: 24px;
        }

        h1 {
            color: #1e293b;
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 6px;
        }

        p.subtitulo {
            color: #64748b;
            font-size: 14px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 18px;
        }

        label {
            font-size: 14px;
            font-weight: 500;
            color: #334155;
        }

        input[type="date"],
        select {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            font-size: 14px;
            color: #1e293b;
            outline: none;
            background-color: #ffffff;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        input[type="date"]:focus,
        select:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
            justify-content: flex-end;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            border: none;
            transition: background-color 0.2s;
        }

        .btn-primary {
            background-color: #2563eb;
            color: #ffffff;
        }

        .btn-primary:hover {
            background-color: #1d4ed8;
        }

        .btn-secondary {
            background-color: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background-color: #e2e8f0;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.php" class="navMarca">Balança Mas Não Cai</a>
        
        <ul class="nav">
            <li><a href="mostra.php" class="nav-link">Home-page</a></li>
            <li><a href="obras.php" class="nav-link">Obras</a></li>
            <li><a href="fases.php" class="nav-link">Fases da Obra</a></li>
            <li><a href="engenheiros.php" class="nav-link">Engenheiros</a></li>
            <li><a href="equipe.php" class="nav-link active">Equipe/Obras</a></li>
            <li><a href="orcamentos.php" class="nav-link">Orçamentos</a></li>
            <li><a href="previsoes.php" class="nav-link">Previsões</a></li>
            <li><a href="logout.php" class="nav-link logout">Sair</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>Alocar Engenheiro na Obra</h1>
                <p class="subtitulo">Associe um engenheiro a uma obra, definindo sua função e período de atuação.</p>
            </div>

            <form action="incluiEquipe.php" method="POST">
                <div class="form-group">
                    <label for="idEngenheiro">Selecione o Engenheiro</label>
                    <select id="idEngenheiro" name="idEngenheiro" required>
                        <option value="">-- Selecione o Engenheiro --</option>
                        <?php 
                        if ($resEng && mysqli_num_rows($resEng) > 0) {
                            while ($eng = mysqli_fetch_assoc($resEng)) {
                                echo "<option value='{$eng['idEngenheiro']}'>" . htmlspecialchars($eng['dsNome']) . " (CREA: " . htmlspecialchars($eng['nrCREA']) . ")</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="idObra">Selecione a Obra</label>
                    <select id="idObra" name="idObra" required>
                        <option value="">-- Selecione a Obra --</option>
                        <?php 
                        if ($resObras && mysqli_num_rows($resObras) > 0) {
                            while ($obra = mysqli_fetch_assoc($resObras)) {
                                echo "<option value='{$obra['idObra']}'>#{$obra['idObra']} - " . htmlspecialchars($obra['Descricao']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="idFuncao">Função Desempenhada na Obra</label>
                    <select id="idFuncao" name="idFuncao" required>
                        <option value="">-- Selecione a Função --</option>
                        <?php 
                        if ($resFunc && mysqli_num_rows($resFunc) > 0) {
                            while ($func = mysqli_fetch_assoc($resFunc)) {
                                echo "<option value='{$func['idFuncao']}'>" . htmlspecialchars($func['dsFuncao']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="dtInicioTrabalho">Data de Início das Atividades</label>
                    <input type="date" id="dtInicioTrabalho" name="dtInicioTrabalho" required>
                </div>

                <div class="form-group">
                    <label for="dtFimTrabalho">Data de Término (se houver)</label>
                    <input type="date" id="dtFimTrabalho" name="dtFimTrabalho">
                </div>

                <div class="form-actions">
                    <a href="equipe.php" class="btn btn-secondary">Cancelar</a>
                    <button type="submit" class="btn btn-primary">Salvar Alocação</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>