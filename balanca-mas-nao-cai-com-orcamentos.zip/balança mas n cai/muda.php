<?php
include_once "sessao.php";

$id = isset($_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;

if ($id <= 0) {
    header('Location: altera.php');
    exit;
}

$erro_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dsFase'])) {
    $dsFase = mysqli_real_escape_string($conn, trim($_POST['dsFase']));

    $sql = "UPDATE fases SET dsFase = '$dsFase' WHERE idFase = $id";
    $result = mysqli_query($conn, $sql);  

    if ($result) {
        mysqli_close($conn);
        header('Location: altera.php?status=sucesso');
        exit;
    } 
    
    $erro_msg = "Erro ao atualizar a fase no banco: " . mysqli_error($conn);
}

$sql_busca = "SELECT idFase, dsFase FROM fases WHERE idFase = $id";
$result_busca = mysqli_query($conn, $sql_busca);

if ($result_busca && $row = mysqli_fetch_assoc($result_busca)) {
    $dsFase_atual = $row['dsFase'];
} else {
    mysqli_close($conn);
    header('Location: altera.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Editar Fase</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 480px;
            padding: 32px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            border: 1px solid #e2e8f0;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        h1 {
            color: #1e293b;
            font-size: 20px;
            font-weight: 600;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            background-color: #f1f5f9;
            color: #475569;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            border-radius: 6px;
            transition: background 0.2s;
        }

        .btn-back:hover {
            background-color: #e2e8f0;
            color: #0f172a;
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            color: #475569;
            margin-bottom: 6px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px 14px;
            font-size: 14px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            outline: none;
            color: #1e293b;
        }

        input[type="text"]:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        input[readonly] {
            background-color: #f1f5f9;
            color: #64748b;
            cursor: not-allowed;
        }

        .btn-submit {
            width: 100%;
            padding: 10px;
            background-color: #2563eb;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.2s;
        }

        .btn-submit:hover {
            background-color: #1d4ed8;
        }

        .alert-error {
            background-color: #fee2e2;
            color: #b91c1c;
            padding: 12px;
            border-radius: 6px;
            font-size: 13px;
            margin-bottom: 16px;
        }
    </style>
</head>
<body>

    <div class="card">
        <div class="header-section">
            <h1>Editar Fase da Obra</h1>
            <a href="altera.php" class="btn-back">← Voltar</a>
        </div>

        <?php if (!empty($erro_msg)) { ?>
            <div class="alert-error"><?php echo htmlspecialchars($erro_msg); ?></div>
        <?php } ?>

        <form method="post" action="muda.php">
            <input type="hidden" name="id" value="<?php echo $id; ?>">

            <div class="form-group">
                <label>Código da Fase</label>
                <input type="text" value="<?php echo $id; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="dsFase">Descrição da Fase</label>
                <input type="text" id="dsFase" name="dsFase" value="<?php echo htmlspecialchars($dsFase_atual); ?>" required autofocus>
            </div>

            <button type="submit" class="btn-submit">Salvar Alterações</button>
        </form>
    </div>

    <?php mysqli_close($conn); ?>
</body>
</html>