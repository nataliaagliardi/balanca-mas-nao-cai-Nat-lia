<?php
include_once "sessao.php";

$mensagem = '';
$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idObra = trim($_POST['idObra'] ?? '');

    if (!empty($idObra)) {
        
        if (file_exists("conexao.php")) {
            include_once "conexao.php";
        }

        try {
            if (isset($pdo) && $pdo instanceof PDO) {
                $sql = "DELETE FROM obras WHERE idObra = :idObra";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':idObra' => $idObra]);
                $sucesso = true;
            } 
            elseif (isset($conn) || isset($conexao)) {
                $db = $conn ?? $conexao;
                $sql = "DELETE FROM obras WHERE idObra = ?";
                $stmt = $db->prepare($sql);
                $stmt->bind_param("i", $idObra);
                if ($stmt->execute()) {
                    $sucesso = true;
                } else {
                    throw new Exception($stmt->error);
                }
            } 
            else {
                $host = '192.168.20.5';
                $user = 'root';
                $pass = '12345'; 
                $dbname = 'balanca_mas_nao_cai';

                $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = "DELETE FROM obras WHERE idObra = :idObra";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':idObra' => $idObra]);
                $sucesso = true;
            }

            if ($sucesso) {
                $mensagem = "Obra excluída com sucesso do sistema!";
            }

        } catch (Exception $e) {
            $sucesso = false;
            if (strpos($e->getMessage(), 'a foreign key constraint fails') !== false) {
                $mensagem = "Não é possível excluir esta obra pois existem fases, equipes ou previsões orçamentárias vinculadas a ela.";
            } else {
                $mensagem = "Erro ao excluir do banco de dados: " . $e->getMessage();
            }
        }

    } else {
        $sucesso = false;
        $mensagem = "Código da obra não informado.";
    }
} else {
    header("Location: excluirObra.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balança mas não cai - Processando Exclusão</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .card {
            background: #ffffff;
            width: 100%;
            max-width: 480px;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
            border: 1px solid #e2e8f0;
            text-align: center;
        }

        .status-icon {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: 0 auto 20px auto;
        }

        .sucesso {
            background-color: #dcfce7;
            color: #16a34a;
        }

        .erro {
            background-color: #fee2e2;
            color: #dc2626;
        }

        h2 {
            font-size: 20px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 8px;
        }

        p {
            font-size: 14px;
            color: #64748b;
            margin-bottom: 28px;
            line-height: 1.5;
            word-break: break-word;
        }

        .btn-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 12px 20px;
            font-size: 14px;
            font-weight: 500;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.2s ease;
            text-align: center;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #2563eb;
            color: #ffffff;
        }

        .btn-primary:hover {
            background-color: #1d4ed8;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
        }

        .btn-secondary {
            background-color: #f8fafc;
            color: #334155;
            border: 1px solid #e2e8f0;
        }

        .btn-secondary:hover {
            background-color: #f1f5f9;
        }
    </style>
</head>
<body>

    <div class="card">
        <?php if ($sucesso): ?>
            <div class="status-icon sucesso">✓</div>
            <h2>Exclusão efetuada!</h2>
            <p><?php echo htmlspecialchars($mensagem); ?></p>

            <div class="btn-group">
                <a href="excluirObra.php" class="btn btn-primary">Excluir outra Obra</a>
                <a href="obras.php" class="btn btn-secondary">Voltar para Menu Obras</a>
            </div>
        <?php else: ?>
            <div class="status-icon erro">✕</div>
            <h2>Ops, ocorreu um erro!</h2>
            <p><?php echo htmlspecialchars($mensagem); ?></p>

            <div class="btn-group">
                <a href="excluirObra.php" class="btn btn-primary">Tentar Novamente</a>
                <a href="obras.php" class="btn btn-secondary">Voltar para Menu Obras</a>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>